package io.hxneyw.repo.compat.jei;

import io.hxneyw.repo.content.recipes.rotaryleaching.RotaryLeachingRecipe;
import io.hxneyw.repo.content.registry.AllModBlocks;
import io.hxneyw.repo.content.registry.AllModFluids;
import java.util.List;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

public final class RotaryLeacherCategory implements IRecipeCategory<RotaryLeachingRecipe> {
    public static final RecipeType<RotaryLeachingRecipe> RECIPE_TYPE = RecipeType.create("sulfuricresonance", "rotary_leaching", RotaryLeachingRecipe.class);
    private final IDrawable icon;
    private final IDrawable slot;
    private final ItemStack machine = new ItemStack(AllModBlocks.ROTARY_LEACHER.get());

    public RotaryLeacherCategory(IGuiHelper helper) {
        icon = helper.createDrawableItemStack(machine);
        slot = helper.getSlotDrawable();
    }

    @Override public @NotNull RecipeType<RotaryLeachingRecipe> getRecipeType() { return RECIPE_TYPE; }
    @Override public @NotNull Component getTitle() { return Component.translatable("recipe.sulfuricresonance.rotary_leaching"); }
    @Override public int getWidth() { return 224; }
    @Override public int getHeight() { return 142; }
    @Override public @NotNull IDrawable getIcon() { return icon; }

    @Override
    public void setRecipe(@NotNull IRecipeLayoutBuilder builder, RotaryLeachingRecipe recipe, @NotNull IFocusGroup focuses) {
        ItemStack[] ingredients = recipe.ingredient().getItems();
        builder.addSlot(RecipeIngredientRole.INPUT, 6, 32).setBackground(slot, -1, -1).addItemStacks(List.of(ingredients))
                .addRichTooltipCallback((view, tooltip) -> tooltip.add(Component.translatable("jei.sulfuricresonance.rotary_leaching.input_count", recipe.inputCount())));
        builder.addSlot(RecipeIngredientRole.INPUT, 6, 56).setBackground(slot, -1, -1)
                .addFluidStack(AllModFluids.SULFURIC_ACID.get(), recipe.fluidAmount());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 198, 32).setBackground(slot, -1, -1).addItemStack(recipe.result());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 198, 56).setBackground(slot, -1, -1).addItemStack(recipe.byproduct());
    }

    @Override
    public void draw(RotaryLeachingRecipe recipe, @NotNull IRecipeSlotsView slots, GuiGraphics graphics, double mouseX, double mouseY) {
        var font = Minecraft.getInstance().font;
        graphics.drawString(font, Component.translatable("jei.sulfuricresonance.rotary_leaching.input_count", recipe.inputCount()), 4, 8, 0x303030, false);

        var pose = graphics.pose();
        pose.pushPose();
        pose.translate(110, 49, 200);
        pose.scale(2.25F, 2.25F, 2.25F);
        graphics.renderItem(machine, -8, -8);
        pose.popPose();

        graphics.drawString(font, Component.translatable("jei.sulfuricresonance.rotary_leaching.acid", recipe.fluidAmount()), 4, 82, 0x665588, false);
        graphics.drawString(font, Component.translatable("jei.sulfuricresonance.rotary_leaching.speed", recipe.minimumSpeed()), 4, 94, 0x303030, false);
        graphics.drawString(font, Component.translatable("jei.sulfuricresonance.rotary_leaching.stress", recipe.minimumSpeed() * 2), 4, 106, 0x303030, false);
        graphics.drawString(font, Component.translatable("jei.sulfuricresonance.rotary_leaching.whisk", 32), 4, 118, 0x303030, false);
        graphics.drawString(font, Component.translatable("jei.sulfuricresonance.rotary_leaching.time", recipe.processingTime() / 20.0), 4, 130, 0x303030, false);
    }
}
