package io.hxneyw.repo.content;

import com.mojang.logging.LogUtils;
import com.simibubi.create.content.equipment.sandPaper.SandPaperItem;
import com.simibubi.create.content.kinetics.simpleRelays.CogwheelBlockItem;
import com.simibubi.create.content.processing.sequenced.SequencedAssemblyItem;
import io.hxneyw.repo.content.items.*;
import io.hxneyw.repo.content.registry.AllModBlocks;
import io.hxneyw.repo.content.registry.AllModFluids;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Item.Properties;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.slf4j.Logger;
@SuppressWarnings("unused")
public class Items {
   private static final Logger LOGGER = LogUtils.getLogger();
   public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("sulfuricresonance");
   public static final DeferredItem<Item> SULFUR = ITEMS.register("sulfur", () -> new SulfurItem(new Properties().stacksTo(64).fireResistant()));
   public static final DeferredItem<Item> ASH_CERAMIC = ITEMS.register("ash_ceramic", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> CINDER_FUEL_BRIQUETTE = ITEMS.register("cinder_fuel_briquette", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<SandPaperItem> CINDER_SANDPAPER = ITEMS.register("cinder_sandpaper", () -> new SandPaperItem(new Properties()));
   public static final DeferredItem<Item> BRIMSTONE_CORE = ITEMS.registerSimpleItem("brimstone_core", new Properties());
   public static final DeferredItem<Item> ASH_BRICK = ITEMS.register("ash_brick", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<BlockItem> ASH_BRICK_BLOCK_ITEM = ITEMS.register("ash_brick_block", () -> new BlockItem(AllModBlocks.ASH_BRICK_BLOCK.get(), new Properties()));
   public static final DeferredItem<BlockItem> ASH_BRICK_PILLAR_ITEM = ITEMS.register("ash_brick_pillar", () -> new BlockItem(AllModBlocks.ASH_BRICK_PILLAR.get(), new Properties()));
   public static final DeferredItem<Item> MOLTEN_EMBER_PELLET = ITEMS.register("molten_ember_pellet", () -> new Item(new Properties().stacksTo(64).fireResistant()));
   public static final DeferredItem<Item> COKE = ITEMS.register("coke", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> INFERNAL_COKE = ITEMS.register("infernal_coke", () -> new Item(new Properties().stacksTo(64).fireResistant()));
   public static final DeferredItem<BlockItem> CARBON_DEPOSIT_BLOCK_ITEM = ITEMS.register("carbon_deposit_block", () -> new BlockItem(AllModBlocks.CARBON_DEPOSIT_BLOCK.get(), new Properties()));
   public static final DeferredItem<Item> SULFUROUS_FUEL_COMPOUND = ITEMS.register("sulfurous_fuel_compound", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<BlockItem> TEMPERED_ASHESIL_ITEM = ITEMS.register("tempered_ashesil", () -> new BlockItem(AllModBlocks.TEMPERED_ASHESIL.get(), new Properties()));
   public static final DeferredItem<CogwheelBlockItem> THERMOCHEMICAL_COGWHEEL_ITEM = ITEMS.register("thermochemical_cogwheel", () -> new CogwheelBlockItem(AllModBlocks.THERMOCHEMICAL_COGWHEEL.get(), new Properties()));
   public static final DeferredItem<BlockItem> TEMPERED_ASHESIL_PANE_ITEM = ITEMS.register("tempered_ashesil_pane", () -> new BlockItem(AllModBlocks.TEMPERED_ASHESIL_PANE.get(), new Properties()));
   public static final DeferredItem<Item> SULFUR_FUEL_BRIQUETTE = ITEMS.register("sulfur_fuel_briquette", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<BlockItem> INFERNAL_CARBON_DEPOSIT_BLOCK_ITEM = ITEMS.register("infernal_carbon_deposit_block", () -> new BlockItem(AllModBlocks.INFERNAL_CARBON_DEPOSIT_BLOCK.get(), new Properties().fireResistant()));
   public static final DeferredItem<BlockItem> ASH_BRICK_SLAB_ITEM = ITEMS.register("ash_brick_slab", () -> new BlockItem(AllModBlocks.ASH_BRICK_SLAB.get(), new Properties()));
   public static final DeferredItem<BlockItem> ASH_BRICK_STAIRS_ITEM = ITEMS.register("ash_brick_stairs", () -> new BlockItem(AllModBlocks.ASH_BRICK_STAIRS.get(), new Properties()));
   public static final DeferredItem<BlockItem> ASH_BRICK_WALL_ITEM = ITEMS.register("ash_brick_wall", () -> new BlockItem(AllModBlocks.ASH_BRICK_WALL.get(), new Properties()));
   public static final DeferredItem<Item> NETHERWOOD_DUST = ITEMS.register("netherwood_dust", () -> new NetherwoodDustItem(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> SPENT_ASH = ITEMS.register("spent_ash", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> EMBER_CATALYST = ITEMS.register("ember_catalyst", () -> new EmberCatalystItem(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> ACTIVATED_SULFUR_CATALYST = ITEMS.register("activated_sulfur_catalyst", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> EMBERSOL = ITEMS.register("embersol", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> BLAZE_SHARD = ITEMS.register("blaze_shard", () -> new Item(new Properties().stacksTo(64).fireResistant()));
   public static final DeferredItem<Item> PYROCLASTIC_POWDER = ITEMS.register("pyroclastic_powder", () -> new Item(new Properties().stacksTo(64).fireResistant()));
   public static final DeferredItem<Item> PYROCLAST_BOMB = ITEMS.register("pyroclast_bomb", () -> new PyroclastBombItem(new Properties().stacksTo(16)));
   public static final DeferredItem<SulfuricAcidFlaskItem> SULFURIC_ACID_FLASK = ITEMS.register("sulfuric_acid_flask", () -> new SulfuricAcidFlaskItem(new Properties().stacksTo(16)));
   public static final DeferredItem<CinderFlareItem> CINDER_FLARE = ITEMS.register("cinder_flare", () -> new CinderFlareItem(new Properties().stacksTo(16).fireResistant()));
   public static final DeferredItem<LitCinderFlareItem> LIT_CINDER_FLARE = ITEMS.register("lit_cinder_flare", () -> new LitCinderFlareItem(new Properties().stacksTo(16).fireResistant()));
   public static final DeferredItem<Item> REINFORCED_CINDER_COMPOUND = ITEMS.register("reinforced_cinder_compound", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> OBSIDIAN_FIBER_MOLD = ITEMS.register("obsidian_fiber_mold", () -> new Item(new Properties().stacksTo(16)));
   @SuppressWarnings("unused")
   public static final DeferredItem<BlockItem> ASH_CERAMIC_CRUCIBLE_ITEM = ITEMS.register("ash_ceramic_crucible", () -> new BlockItem(AllModBlocks.ASH_CERAMIC_CRUCIBLE.get(), new Properties()));
   public static final DeferredItem<Item> OBSIDIAN_FIBER_MOLD_FILLED = ITEMS.register("obsidian_fiber_mold_filled", () -> new Item(new Properties().stacksTo(16)));
   @SuppressWarnings("unused")

   public static final DeferredItem<CogwheelBlockItem> LARGE_THERMOCHEMICAL_COGWHEEL_ITEM = ITEMS.register("large_thermochemical_cogwheel", () -> new CogwheelBlockItem(AllModBlocks.LARGE_THERMOCHEMICAL_COGWHEEL.get(), new Properties()));
   public static final DeferredItem<BlockItem> SULFUR_BURNER_ITEM = ITEMS.register("sulfur_burner", () -> new BlockItem(AllModBlocks.SULFUR_BURNER.get(), new Properties()));
   public static final DeferredItem<BlockItem> SULFURIC_RESONANCE_CHAMBER_ITEM = ITEMS.register("sulfuric_resonance_chamber", () -> new BlockItem(AllModBlocks.SULFURIC_RESONANCE_CHAMBER.get(), new Properties()));
   public static final DeferredItem<BlockItem> ROTARY_LEACHER_ITEM = ITEMS.register("rotary_leacher", () -> new BlockItem(AllModBlocks.ROTARY_LEACHER.get(), new Properties().stacksTo(64)));
   public static final DeferredItem<Item> MINERAL_TAILINGS = ITEMS.register("mineral_tailings", () -> new Item(new Properties()));
   public static final DeferredItem<BlockItem> CATALYST_BED_ITEM = ITEMS.register("catalyst_bed", () -> new BlockItem(AllModBlocks.CATALYST_BED.get(), new Properties()));
   public static final DeferredItem<BlockItem> RESONANT_HEAT_INJECTOR_ITEM = ITEMS.register("resonant_heat_injector", () -> new BlockItem(AllModBlocks.RESONANT_HEAT_INJECTOR.get(), new Properties()));
   public static final DeferredItem<BlockItem> ASHESIL_ITEM = ITEMS.register("ashesil", () -> new BlockItem(AllModBlocks.ASHESIL.get(), new Properties()));
   public static final DeferredItem<Item> WET_ASH_CERAMIC = ITEMS.register("wet_ash_ceramic", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> UNFIRED_ASH_BRICK = ITEMS.register("unfired_ash_brick", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> ACID_RESISTANT_CERAMIC = ITEMS.register("acid_resistant_ceramic", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<BlockItem> ASHESIL_PANE_ITEM = ITEMS.register("ashesil_pane", () -> new BlockItem(AllModBlocks.ASHESIL_PANE.get(), new Properties()));
   public static final DeferredItem<LivingEmberLampItem> LIVING_EMBER_LAMP_ITEM = ITEMS.register("living_ember_lamp", () -> new LivingEmberLampItem(AllModBlocks.LIVING_EMBER_LAMP.get(), new Properties()));
   public static final DeferredItem<Item> OBSIDIAN_FIBER = ITEMS.register("obsidian_fiber", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> OBSIDIAN_CLOTH = ITEMS.register("obsidian_cloth", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> UNFINISHED_FILAMENT = ITEMS.register("unfinished_filament", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> CINDER_FILAMENT = ITEMS.register("cinder_filament", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> ACID_ETCHED_COPPER_SHEET = ITEMS.register("acid_etched_copper_sheet", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> RESONANT_COPPER_INGOT = ITEMS.register("resonant_copper_ingot", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> RESONANT_IRON_INGOT = ITEMS.register("resonant_iron_ingot", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> RESONANT_GOLD_INGOT = ITEMS.register("resonant_gold_ingot", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> RESONANT_COPPER_SHEET = ITEMS.register("resonant_copper_sheet", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> RESONANT_IRON_SHEET = ITEMS.register("resonant_iron_sheet", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> RESONANT_GOLD_SHEET = ITEMS.register("resonant_gold_sheet", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> UNFINISHED_THERMAL_MATRIX = ITEMS.register("unfinished_thermal_matrix", () -> new Item(new Properties().stacksTo(64)));

   public static final DeferredItem<Item> THERMAL_MATRIX = ITEMS.register("thermal_matrix", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> LOGIC_BANK = ITEMS.register("logic_bank", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<SequencedAssemblyItem> INCOMPLETE_THERMOCHEMICAL_CASING = ITEMS.register("incomplete_thermochemical_casing", () -> new SequencedAssemblyItem(new Properties()));
   public static final DeferredItem<Item> THERMOCHEMICAL_CASING = ITEMS.register("thermochemical_casing", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> LATEX_CLUMP = ITEMS.register("latex_clump", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<ThermalRelaySwitchItem> THERMAL_RELAY_SWITCH_ITEM = ITEMS.register("thermal_relay_switch", () -> new ThermalRelaySwitchItem(AllModBlocks.THERMAL_RELAY_SWITCH.get(), new Properties()));
   public static final DeferredItem<ThermalBatteryItem> THERMAL_BATTERY_ITEM = ITEMS.register("thermal_battery", () -> new ThermalBatteryItem(AllModBlocks.THERMAL_BATTERY.get(), new Properties().stacksTo(1)));
   public static final DeferredItem<ThermalGaugeItem> THERMAL_GAUGE_ITEM = ITEMS.register("thermal_gauge", () -> new ThermalGaugeItem(AllModBlocks.THERMAL_GAUGE.get(), new Properties()));
   public static final DeferredItem<ThermalWarningAlarmItem> THERMAL_WARNING_ALARM_ITEM = ITEMS.register("thermal_warning_alarm", () -> new ThermalWarningAlarmItem(AllModBlocks.THERMAL_WARNING_ALARM.get(), new Properties()));
   public static final DeferredItem<BlockItem> PROCESS_MONITOR_ITEM = ITEMS.register("process_monitor", () -> new BlockItem(AllModBlocks.PROCESS_MONITOR.get(), new Properties()));
   public static final DeferredItem<ProcessGaugeItem> PROCESS_GAUGE_ITEM = ITEMS.register("process_gauge", () -> new ProcessGaugeItem(AllModBlocks.PROCESS_GAUGE.get(), new Properties()));
   public static final DeferredItem<CombustionBeltConnectorItem> COMBUSTION_BELT_CONNECTOR = ITEMS.register("combustion_belt_connector", () -> new CombustionBeltConnectorItem(new Properties().stacksTo(64)));
   public static final DeferredItem<BlockItem> THERMOCHEMICAL_CONDUIT_ITEM = ITEMS.register("thermochemical_conduit", () -> new BlockItem(AllModBlocks.THERMOCHEMICAL_CONDUIT.get(), new Properties()));
   public static final DeferredItem<BlockItem> THERMOCHEMICAL_SHAFT_ITEM = ITEMS.register("thermochemical_shaft", () -> new BlockItem(AllModBlocks.THERMOCHEMICAL_SHAFT.get(), new Properties()));
   public static final DeferredItem<BlockItem> THERMOCHEMICAL_BOILER_INTERFACE_ITEM = ITEMS.register("thermochemical_boiler_interface", () -> new BlockItem(AllModBlocks.THERMOCHEMICAL_BOILER_INTERFACE.get(), new Properties()));
   public static final DeferredItem<BlockItem> THERMOCHEMICAL_CLUTCH_ITEM = ITEMS.register("thermochemical_clutch", () -> new BlockItem(AllModBlocks.THERMOCHEMICAL_CLUTCH.get(), new Properties()));
   public static final DeferredItem<BlockItem> THERMOCHEMICAL_GEARBOX_ITEM = ITEMS.register("thermochemical_gearbox", () -> new BlockItem(AllModBlocks.THERMOCHEMICAL_GEARBOX.get(), new Properties()));
   public static final DeferredItem<BlockItem> PARALLEL_THERMOCHEMICAL_GEARBOX_ITEM = ITEMS.register("parallel_thermochemical_gearbox", () -> new BlockItem(AllModBlocks.PARALLEL_THERMOCHEMICAL_GEARBOX.get(), new Properties()));
   public static final DeferredItem<BlockItem> THERMOCHEMICAL_LINK_DRIVE_ITEM = ITEMS.register("thermochemical_link_drive", () -> new BlockItem(AllModBlocks.THERMOCHEMICAL_LINK_DRIVE.get(), new Properties()));
   public static final DeferredItem<Item> UNREFINED_RUBBER = ITEMS.register("unrefined_rubber", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> VULCANIZED_RUBBER = ITEMS.register("vulcanized_rubber", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> MOLDED_RUBBER_GASKET = ITEMS.register("molded_rubber_gasket", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> INFERNAL_IMPELLER = ITEMS.register("infernal_impeller", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> IMPELLER_BLADE = ITEMS.register("impeller_blade", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> SHEATHED_IMPELLER_BLADE = ITEMS.register("sheathed_impeller_blade", () -> new SheathedImpellerBladeItem(new Properties().stacksTo(1)));
   public static final DeferredItem<BlockItem> PERFORATED_SPRITZER = ITEMS.register("perforated_spritzer", () -> new BlockItem(AllModBlocks.PERFORATED_SPRITZER.get(), new Properties()));
   public static final DeferredItem<PrecisionSpritzerBlockItem> PRECISION_SPRITZER = ITEMS.register("precision_spritzer", () -> new PrecisionSpritzerBlockItem(AllModBlocks.PERFORATED_SPRITZER.get(), new Properties()));
   public static final DeferredItem<Item> FLAMEBORNE_CORE = ITEMS.register("flameborne_core", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> RUBBER_PADDING = ITEMS.register("rubber_padding", () -> new RubberPaddingBlockItem(AllModBlocks.RUBBER_PADDING.get(), new Properties()));
   public static final DeferredItem<Item> CORRUPT_BLAZE_CAKE = ITEMS.register("corrupt_blaze_cake", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> SOUL_FIRED_BLAZE_CAKE = ITEMS.register("soul_fired_blaze_cake", () -> new Item(new Properties().stacksTo(64)));
   public static final DeferredItem<Item> MOLTEN_ROTOR_FURNACE = ITEMS.register("molten_rotor_furnace", () -> new BlockItem(AllModBlocks.MOLTEN_ROTOR_FURNACE.get(), new Properties().stacksTo(64)));
   public static final DeferredItem<BlockItem> SULFUR_BLOCK = ITEMS.register("sulfur_block", () -> new BlockItem(AllModBlocks.SULFUR_BLOCK.get(), new Properties()));
   public static final DeferredItem<BucketItem> SULFURIC_ACID_BUCKET = ITEMS.register("sulfuric_acid_bucket", () -> new BucketItem(AllModFluids.SULFURIC_ACID.get(), new Properties().craftRemainder(net.minecraft.world.item.Items.BUCKET).stacksTo(1)));
   public static final DeferredItem<SuperphosphateFertilizerItem> SUPERPHOSPHATE_FERTILIZER = ITEMS.register("superphosphate_fertilizer", () -> new SuperphosphateFertilizerItem(new Properties().stacksTo(64)));

   public static final DeferredItem<Item> THERMITE_CHARGE = ITEMS.register("thermite_charge", () -> new Item(new Item.Properties().stacksTo(64).fireResistant()));


   public static final DeferredItem<Item> BRIMSTONE_BRIQUETTE = ITEMS.register("brimstone_briquette", () -> new Item(new Item.Properties().stacksTo(64).fireResistant()));



   public static void register(IEventBus eventBus) {
      LOGGER.info("Registering Sulfuric Resonance items");
      ITEMS.register(eventBus);
   }
}
