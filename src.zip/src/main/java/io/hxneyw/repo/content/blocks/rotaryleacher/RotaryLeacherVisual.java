package io.hxneyw.repo.content.blocks.rotaryleacher;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityVisual;
import com.simibubi.create.content.kinetics.base.RotatingInstance;
import com.simibubi.create.foundation.render.AllInstanceTypes;
import dev.engine_room.flywheel.api.instance.Instance;
import dev.engine_room.flywheel.api.visual.BlockEntityVisual;
import dev.engine_room.flywheel.api.visualization.VisualizationContext;
import dev.engine_room.flywheel.lib.model.Models;
import dev.engine_room.flywheel.lib.visual.SimpleTickableVisual;
import io.hxneyw.repo.client.ClientModEvents;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;

import java.util.function.Consumer;

public final class RotaryLeacherVisual extends KineticBlockEntityVisual<RotaryLeacherBlockEntity>
        implements SimpleTickableVisual {
    private final RotatingInstance cogwheel;
    private final RotatingInstance shaft;
    private final RotatingInstance whisk;

    private RotaryLeacherVisual(VisualizationContext context, RotaryLeacherBlockEntity blockEntity, float partialTick) {
        super(context, blockEntity, partialTick);
        var instancer = instancerProvider().instancer(AllInstanceTypes.ROTATING, Models.partial(AllPartialModels.SHAFTLESS_COGWHEEL));
        cogwheel = instancer.createInstance().rotateToFace(Direction.UP).setup(blockEntity, Axis.Y).setPosition(getVisualPosition());
        cogwheel.setChanged();
        shaft = instancerProvider().instancer(AllInstanceTypes.ROTATING, Models.partial(AllPartialModels.COGWHEEL_SHAFT))
                .createInstance().rotateToFace(Direction.UP).setup(blockEntity, Axis.Y).setPosition(getVisualPosition());
        shaft.setChanged();
        whisk = instancerProvider().instancer(AllInstanceTypes.ROTATING, Models.partial(ClientModEvents.ROTARY_LEACHER_WHISK))
                .createInstance().rotateToFace(Direction.UP).setPosition(getVisualPosition().above());
        updateWhiskSpeed();
    }

    public static BlockEntityVisual<RotaryLeacherBlockEntity> create(
            VisualizationContext context, RotaryLeacherBlockEntity blockEntity, float partialTick) {
        return new RotaryLeacherVisual(context, blockEntity, partialTick);
    }

    @Override public void update(float partialTick) {
        cogwheel.setup(blockEntity, Axis.Y).setChanged();
        shaft.setup(blockEntity, Axis.Y).setChanged();
        updateWhiskSpeed();
    }

    @Override public void tick(Context context) { }

    private void updateWhiskSpeed() {
        float speed = Math.abs(blockEntity.getSpeed()) >= 64 ? Math.copySign(32.0F, blockEntity.getSpeed()) : 0.0F;
        whisk.setup(blockEntity, Axis.Y, speed).setPosition(getVisualPosition().above()).setChanged();
    }

    @Override public void updateLight(float partialTick) {
        relight(cogwheel);
        relight(shaft);
        relight(whisk);
    }

    @Override protected void _delete() {
        cogwheel.delete();
        shaft.delete();
        whisk.delete();
    }

    @Override public void collectCrumblingInstances(Consumer<Instance> consumer) {
        consumer.accept(cogwheel);
        consumer.accept(shaft);
        consumer.accept(whisk);
    }
}
